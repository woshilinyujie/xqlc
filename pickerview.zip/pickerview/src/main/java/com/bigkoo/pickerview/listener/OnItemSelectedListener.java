package com.bigkoo.pickerview.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
